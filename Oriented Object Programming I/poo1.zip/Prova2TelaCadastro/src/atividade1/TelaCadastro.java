package atividade1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import net.miginfocom.swing.MigLayout;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaCadastro extends JFrame {

	private JPanel contentPane;
	private JTextField fieldNome;
	private JTextField fieldEndereco;
	private JTextField fieldCPF;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaCadastro frame = new TelaCadastro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaCadastro() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.PINK);
		contentPane.add(panel1, BorderLayout.NORTH);
		
		JLabel lblTelaDeCadastro = new JLabel("TELA DE CADASTRO");
		lblTelaDeCadastro.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel1.add(lblTelaDeCadastro);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.PINK);
		contentPane.add(panel2, BorderLayout.CENTER);
		panel2.setLayout(new MigLayout("", "[][grow]", "[][][][][grow]"));
		
		JLabel lblNome = new JLabel("Nome");
		panel2.add(lblNome, "cell 0 0,alignx trailing");
		
		fieldNome = new JTextField();
		panel2.add(fieldNome, "cell 1 0,growx");
		fieldNome.setColumns(10);
		
		JLabel lblEndereco = new JLabel("Endereço");
		panel2.add(lblEndereco, "cell 0 1,alignx trailing");
		
		fieldEndereco = new JTextField();
		panel2.add(fieldEndereco, "cell 1 1,growx");
		fieldEndereco.setColumns(10);
		
		JLabel lblCpf = new JLabel("CPF");
		panel2.add(lblCpf, "cell 0 2,alignx trailing");
		
		fieldCPF = new JTextField();
		panel2.add(fieldCPF, "cell 1 2,growx");
		fieldCPF.setColumns(10);
		
		JLabel lblProfissao = new JLabel("Profissão");
		panel2.add(lblProfissao, "cell 0 3,alignx trailing");
		
		JComboBox<String> comboProfissao = new JComboBox<String>();
		comboProfissao.addItem(" ");
		comboProfissao.addItem("Informata biomédico");
		comboProfissao.addItem("Médico");
		panel2.add(comboProfissao, "cell 1 3,growx");
		
		JLabel lblObservaes = new JLabel("Observações");
		panel2.add(lblObservaes, "cell 0 4");
		
		JScrollPane scrollPane = new JScrollPane();
		panel2.add(scrollPane, "cell 1 4,grow");
		
		
		JPanel panel3 = new JPanel();
		panel3.setBackground(Color.PINK);
		contentPane.add(panel3, BorderLayout.SOUTH);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(btnCadastrar, "Cadastrado com sucesso!");
		
			}
		});
		panel3.add(btnCadastrar);
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fieldNome.setText("  ");
				fieldEndereco.setText(" ");
				fieldCPF.setText("  ");
			}
		});
		panel3.add(btnLimpar);
	}

}
