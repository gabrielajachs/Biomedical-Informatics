package aulaParte1;

public interface Salario {
	
	public static final double SALARIO_MINIMO = 788.00;
	
	public abstract double getSalarioLiquido();
	public abstract double getQuantidadeSalarioMinimo();
	
	

}
