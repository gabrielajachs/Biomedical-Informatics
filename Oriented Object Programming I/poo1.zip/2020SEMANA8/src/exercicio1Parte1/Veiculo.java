package exercicio1Parte1;

public interface Veiculo {

	public static void ajustar() {
		System.out.println("Ajustando veiculo!");
	}
	
	public static void limpar() {
		System.out.println("Limpando veiculo!");
	}
	
	public static void verificar() {
		System.out.println("Verificando veiculo!");
	}

}
