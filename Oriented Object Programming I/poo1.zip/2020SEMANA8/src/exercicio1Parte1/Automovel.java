package exercicio1Parte1;

public class Automovel implements Veiculo{
	
	public void ajustar() {
		System.out.println("Ajustando automovel!");
	}
	
	public void limpar() {
		System.out.println("Limpando automovel!");
	}
	
	public void verificar() {
		System.out.println("Verificando automovel!");
	}
	
	

}
