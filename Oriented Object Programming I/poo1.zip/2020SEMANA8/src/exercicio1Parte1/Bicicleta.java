package exercicio1Parte1;

public class Bicicleta implements Veiculo{
	
	public void ajustar() {
		System.out.println("Ajustando bicicleta!");
	}
	
	public void limpar() {
		System.out.println("Limpando bicicleta!");
	}
	
	public void verificar() {
		System.out.println("Verificando bicicleta!");
	}


}
