package exercicio1Parte2;

public class Cachorro implements FuncaoAnimal {
	
	public void cacaAnimal() {
		System.out.println("Cachorro caçando o rato!");
	}
	
	public void fazerBarulho() {
		System.out.println("Cachorro fazendo barulho");
	}
	

}
