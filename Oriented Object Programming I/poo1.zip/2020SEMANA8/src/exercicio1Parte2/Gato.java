package exercicio1Parte2;

public class Gato implements FuncaoAnimal {

	public void cacaAnimal() {
		System.out.println("Gato caçando o rato!");
	}
	
	public void fazerBarulho() {
		System.out.println("Gato fazendo barulho");
	}

}
