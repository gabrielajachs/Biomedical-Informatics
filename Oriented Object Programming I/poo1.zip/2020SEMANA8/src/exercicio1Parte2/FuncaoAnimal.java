package exercicio1Parte2;

public interface FuncaoAnimal {
	
	public abstract void fazerBarulho();
	public abstract void cacaAnimal();

}