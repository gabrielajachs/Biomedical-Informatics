package exercicio1parte1;

public class Gerente {

}
