package modelo;

import javax.swing.JOptionPane;

public class OperaçãoLogin {
	private String usuario;
	private String senha;
	
	public OperaçãoLogin(String usuario, String senha) {
		super();
		this.usuario = usuario;
		this.senha = senha;
	}

	public void login() {
		
	}
	
	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
	
}
