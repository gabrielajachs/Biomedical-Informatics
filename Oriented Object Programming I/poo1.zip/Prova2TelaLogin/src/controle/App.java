package controle;

import modelo.OperaçãoLogin;
import visao.TelaLogin;

public class App {

	public static void main(String[] args) {
		TelaLogin tela = new TelaLogin();
		tela.setVisible(true);
		OperaçãoLogin l = new OperaçãoLogin(null, null);
		LoginControle controle = new LoginControle(tela, l);	
	}
}