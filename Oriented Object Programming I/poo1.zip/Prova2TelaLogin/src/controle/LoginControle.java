package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import modelo.OperaçãoLogin;
import visao.TelaLogin;

public class LoginControle implements ActionListener{

	
		private TelaLogin tela;
		private OperaçãoLogin lo;
		
		public LoginControle(TelaLogin tela, OperaçãoLogin lo) {
			super();
			this.tela = tela;
			this.lo = lo;
			this.tela.getBtnAutenticar().addActionListener(this);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if (e.getActionCommand().equals("Autenticar"))
			{
				this.lo.setUsuario(this.tela.getFieldUsuario().getText());
				this.lo.setSenha(this.tela.getFieldSenha().getText());
				
				Object usuario = null;
				Object senha = null;
				if (usuario.equals("admin") && senha.equals("admin"))
				{
					System.out.println("Autenticou com sucesso");
					
				}
			}		
		}
}
