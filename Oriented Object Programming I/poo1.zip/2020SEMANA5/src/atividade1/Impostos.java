package atividade1;

public interface Impostos {

	public abstract double calculaIPVA(int ano, double motor);
	public abstract double calculaSeguro(int ano, double motor);
	
}
