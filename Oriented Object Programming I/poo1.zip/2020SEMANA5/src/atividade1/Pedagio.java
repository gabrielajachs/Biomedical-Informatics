package atividade1;

public interface Pedagio {

	public abstract double calculaPedagio(int numE);
	
}
