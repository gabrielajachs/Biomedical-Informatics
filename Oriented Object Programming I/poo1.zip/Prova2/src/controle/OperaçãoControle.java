package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import modelo.Operação;
import visao.Janela;

public class OperaçãoControle implements ActionListener {
//aqui na OPERACAOCONTROLE tu vai ter que colocar esse IMPLEMENTS
// assim, ele vai conseguir fazer o botao funcionar, que usa o ACTIONLISTENER
//dai quando importar o ACTIONLISTENER, vai aparecer isso aqui de baixo
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		//dai esse codigo aqui tem que fazer, pra poder pegar o n1 da operação
		//e fazer com que o numero que tu escrever na janela, seja esse n1 e n2
		//que vai pegar eles e vai fazer a operação de somar!
		if (e.getActionCommand().equals("Somar")) {
			this.opera.setN1(Float.parseFloat(this.jan.getFieldN1().getText()));
			this.opera.setN2(Float.parseFloat(this.jan.getFieldN2().getText()));
			this.jan.getFieldResultado().setText(String.valueOf(opera.Somar()));
			System.out.println(opera.Somar());
		}	
		}
		
	
	
	private Operação opera;
	private Janela jan;
	
	public OperaçãoControle(Operação opera, Janela jan) {
		super();
		this.opera = opera;
		this.jan = jan;
		
		this.jan.getBtnSomar().addActionListener(this);
		
		
		
		
	}
	
	
	
	
}
