package controle;

import modelo.Operação;
import visao.Janela;

public class App {

	public static void main(String[] args) {
		Janela tela = new Janela();
		Operação  Op = new Operação(0, 0);
		
		tela.setVisible(true);
		OperaçãoControle Oc = new OperaçãoControle(Op, tela);
	}
	
	
}

// aqui no pacote CONTROLE na classe APP, criar um MAIN sempre
// e nesse main tu vai importar a janela que tu criou da visao
// e vai importar tambem a classe OPERACAO
// porque é aqui na APP que tu vai fazer as duas se interligarem
// vai importar pacote MODELO e pacote VISAO