package visao;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import java.awt.Font;
import java.awt.MenuBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Janela extends JFrame {

	//vai pedir pra importar tudo que dá.. importa!
	// declarar todas as variaveis globais que tiver de botão e coisa
	private JPanel contentPane;
	private JTextField fieldResultado;
	private JTextField fieldN1;
	private JTextField fieldN2;
	private JMenu mnArquivo;
	private JMenuItem mntmSair;
	private JLabel lblN1;
	private JLabel lblN2;
	private JButton btnSomar;
	private JButton btnLimpar;
	private JMenuBar menuBar;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Janela frame = new Janela();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
//gerar os getters and setters dessas variaveis globais
// SEMPRE DESMARCAR O DO CONTENT PANE!!!!!!!
	public JTextField getFieldResultado() {
		return fieldResultado;
	}

	public void setFieldResultado(JTextField fieldResultado) {
		this.fieldResultado = fieldResultado;
	}

	public JTextField getFieldN1() {
		return fieldN1;
	}

	public void setFieldN1(JTextField fieldN1) {
		this.fieldN1 = fieldN1;
	}

	public JTextField getFieldN2() {
		return fieldN2;
	}

	public void setFieldN2(JTextField fieldN2) {
		this.fieldN2 = fieldN2;
	}

	public JMenu getMnArquivo() {
		return mnArquivo;
	}

	public void setMnArquivo(JMenu mnArquivo) {
		this.mnArquivo = mnArquivo;
	}

	public JMenuItem getMntmSair() {
		return mntmSair;
	}

	public void setMntmSair(JMenuItem mntmSair) {
		this.mntmSair = mntmSair;
	}

	public JLabel getLblN1() {
		return lblN1;
	}

	public void setLblN1(JLabel lblN1) {
		this.lblN1 = lblN1;
	}

	public JLabel getLblN2() {
		return lblN2;
	}

	public void setLblN2(JLabel lblN2) {
		this.lblN2 = lblN2;
	}

	public JButton getBtnSomar() {
		return btnSomar;
	}

	public void setBtnSomar(JButton btnSomar) {
		this.btnSomar = btnSomar;
	}

	public JButton getBtnLimpar() {
		return btnLimpar;
	}

	public void setBtnLimpar(JButton btnLimpar) {
		this.btnLimpar = btnLimpar;
	}

	//sempre apagar o MAIN que tava aqui

	/**
	 * Create the frame.
	 */
	public Janela() {
		setTitle("Prova 2 POO I");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 250);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnArquivo = new JMenu("Arquivo");
		menuBar.add(mnArquivo);
		
		//apagar o que tem antes e deixar só o nome do botao
		mntmSair = new JMenuItem("Sair");
		mntmSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
				
			}
		});
		mnArquivo.add(mntmSair);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.PINK);
		panel1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		contentPane.add(panel1, BorderLayout.NORTH);
		
		fieldResultado = new JTextField();
		fieldResultado.setFont(new Font("Tahoma", Font.PLAIN, 30));
		panel1.add(fieldResultado);
		fieldResultado.setColumns(0);
		fieldResultado.setPreferredSize(new Dimension(600, 70));
		
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.PINK);
		panel2.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		contentPane.add(panel2, BorderLayout.CENTER);
		
		lblN1 = new JLabel("Primeiro Número");
		lblN1.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel2.add(lblN1);
		
		fieldN1 = new JTextField();
		fieldN1.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel2.add(fieldN1);
		fieldN1.setColumns(10);
		
		lblN2 = new JLabel("Segundo Número");
		lblN2.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel2.add(lblN2);
		
		fieldN2 = new JTextField();
		fieldN2.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel2.add(fieldN2);
		fieldN2.setColumns(10);
		
		JPanel panel3 = new JPanel();
		panel3.setBackground(Color.PINK);
		panel3.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		contentPane.add(panel3, BorderLayout.SOUTH);
		
		btnSomar = new JButton("Somar");
		panel3.add(btnSomar);
		
		btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fieldN1.setText(" ");
				fieldN2.setText(" ");
				fieldResultado.setText(" ");
				
			}
		});
		panel3.add(btnLimpar);
	}

}
