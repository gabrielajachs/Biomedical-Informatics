package modelo;

public class Operação {

	private float n1;
	private float n2;
	
	
	public Operação(float n1, float n2) {
		super();
		this.n1 = n1;
		this.n2 = n2;
	}
	public float getN1() {
		return n1;
	}
	public void setN1(float n1) {
		this.n1 = n1;
	}
	public float getN2() {
		return n2;
	}
	public void setN2(float n2) {
		this.n2 = n2;
	}
	
	//lembrar de criar esse metodo aqui pra poder somar!
	public float Somar() {
		return n1+n2; //aqui que faz a conta da calculadora
	}
	

	//aqui é onde vai acontecer a operação da calculadora, que é SOMAR os dois numeros!
	//entao, criar as variaveis globais dos numeros.. que é o n1 e o n2!
	// colocar os constructor using field
	// colocar os getters and setters
	
}
