package excecoes;

public class ProgramaPrincipal2 {
	
	public static void main(String[] args) {
		
		int[] numeros = new int[3];
		
	}

}
