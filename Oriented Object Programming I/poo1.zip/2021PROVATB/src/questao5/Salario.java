package questao5;

public interface Salario {

	public static final int qthoras = 0;
	public static final double valhora=0.0;
	public abstract double getSalarioFinal();

}
