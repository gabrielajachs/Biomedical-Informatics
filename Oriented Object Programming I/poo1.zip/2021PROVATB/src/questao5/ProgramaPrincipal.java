package questao5;

public class ProgramaPrincipal {
	
	public static void main(String[] args) {
		
		Salario f;
		
		f = new Funcionario("Gabriela", 26, 1234567, 12, 1000);
		System.out.println(f);
		
		
	}

}
