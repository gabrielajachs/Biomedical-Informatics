package exemplo1;

public class Veiculo {
	public void ajustar() {
		System.out.println("Ajustando veiculo!");
	}
	
	public void limpar() {
		System.out.println("Limpando veiculo!");
	}
	
	public void verificar() {
		System.out.println("Verificando veiculo!");
	}

}
