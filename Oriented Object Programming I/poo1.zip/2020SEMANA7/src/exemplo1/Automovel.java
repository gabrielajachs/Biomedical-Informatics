package exemplo1;

public class Automovel extends Veiculo{
	public void ajustar() {
		System.out.println("Ajustando automovel!");
	}
	
	public void limpar() {
		System.out.println("Limpando automovel!");
	}
	
	public void verificar() {
		System.out.println("Verificando automovel!");
	}

}
