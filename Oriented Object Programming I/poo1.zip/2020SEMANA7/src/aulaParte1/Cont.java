package aulaParte1;

public interface Cont <E>{
	E get();
	void Set(E e);

}
