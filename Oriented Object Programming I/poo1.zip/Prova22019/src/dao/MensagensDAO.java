package dao;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import modelo.Mensagens;

public class MensagensDAO {

	public MensagensDAO() {

	}

	public void enviar(String mensagem) {

		File arq = new File("arquivo.txt");
		FileWriter fw = null;
		PrintWriter pw = null;

		try {
			fw = new FileWriter(arq);
			pw = new PrintWriter(fw);

			pw.println(mensagem);
			pw.flush();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pw.close();
			try {
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public Mensagens receber(Mensagens mensagem) throws IOException {
		FileReader fr = null;
		BufferedReader br = null;

		File arq = new File("arquivo.txt");
		if (arq.exists()) {

			try {

				fr = new FileReader(arq);
				br = new BufferedReader(fr);

				String recebida = br.readLine();

				mensagem.setRecebida(recebida);

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				fr.close();
				br.close();
			}

		} else {
			System.out.println("N�o existe um arquivo para a leitura de uma mensagem.");
		}
		return mensagem;
	}
}
