package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JOptionPane;

import dao.MensagensDAO;
import modelo.Mensagens;
import visao.Janela;

public class ControleMensagens implements ActionListener {

	Janela janela;
	Mensagens mensagens;
	MensagensDAO mensagensDao;

	public ControleMensagens(Janela janela, Mensagens mensagens) {
		super();
		this.janela = janela;
		this.mensagens = mensagens;
		mensagensDao = new MensagensDAO();

		this.janela.getBtnEnviar().addActionListener(this);
		this.janela.getBtnLimparTela().addActionListener(this);
		this.janela.getBtnReceber().addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Enviar")) {
			mensagens.setEnviada(janela.getTextFieldEnviaMensagem().getText());

			if (mensagens.getEnviada().isEmpty()) {
				JOptionPane.showMessageDialog(janela, "O campo de envio de mensagens deve estar preenchido!");
			} else {
				mensagensDao.enviar(mensagens.getEnviada());
				JOptionPane.showMessageDialog(janela, "Mensagem enviada com sucesso!");
			}

		}

		if (e.getActionCommand().equals("Limpar Tela")) {
			janela.limpar();
		}

		if (e.getActionCommand().equals("Receber")) {
			try {

				janela.getTextFieldRecebeMensagem().setText(mensagensDao.receber(mensagens).getRecebida());

			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}
