package controle;

import modelo.Mensagens;
import visao.Janela;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Janela jan = new Janela();
		jan.setVisible(true);
		Mensagens men = new Mensagens();
		
		ControleMensagens con = new ControleMensagens(jan, men);
	}

}
