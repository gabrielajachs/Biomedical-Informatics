package modelo;

public class Mensagens {
	private String enviada;
	private String recebida;

	public Mensagens(String enviada, String recebida) {
		super();
		this.enviada = enviada;
		this.recebida = recebida;
	}
	
	public Mensagens() {
	}

	public String getEnviada() {
		return enviada;
	}

	public void setEnviada(String enviada) {
		this.enviada = enviada;
	}

	public String getRecebida() {
		return recebida;
	}

	public void setRecebida(String recebida) {
		this.recebida = recebida;
	}

}
