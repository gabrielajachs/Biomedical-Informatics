package visao;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;

public class Janela extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldEnviaMensagem;
	private JTextField textFieldRecebeMensagem;
	private JButton btnEnviar;
	private JButton btnReceber;
	private JButton btnLimparTela;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Janela frame = new Janela();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Janela() {
		setTitle("JANELA MENSAGENS");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 461, 178);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.PINK);
		contentPane.add(panel1);
		panel1.setLayout(new GridLayout(4, 1, 0, 0));
		
		JLabel lblEnviaMensagem = new JLabel("Envia Mensagem");
		lblEnviaMensagem.setHorizontalAlignment(SwingConstants.CENTER);
		lblEnviaMensagem.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel1.add(lblEnviaMensagem);
		
		textFieldEnviaMensagem = new JTextField();
		textFieldEnviaMensagem.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldEnviaMensagem.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel1.add(textFieldEnviaMensagem);
		textFieldEnviaMensagem.setColumns(10);
		
		JLabel lblRecebeMensagem = new JLabel("Recebe Mensagem");
		lblRecebeMensagem.setHorizontalAlignment(SwingConstants.CENTER);
		lblRecebeMensagem.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel1.add(lblRecebeMensagem);
		
		textFieldRecebeMensagem = new JTextField();
		textFieldRecebeMensagem.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldRecebeMensagem.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel1.add(textFieldRecebeMensagem);
		textFieldRecebeMensagem.setColumns(10);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.PINK);
		contentPane.add(panel2);
		
		btnEnviar = new JButton("Enviar");
		btnEnviar.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel2.add(btnEnviar);
		
		btnReceber = new JButton("Receber");
		btnReceber.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel2.add(btnReceber);
		
		btnLimparTela = new JButton("Limpar Tela");
		btnLimparTela.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel2.add(btnLimparTela);
		
		
	}
	
	public void limpar(){
		textFieldEnviaMensagem.setText("");
		textFieldRecebeMensagem.setText("");
	}
	
	public JTextField getTextFieldEnviaMensagem() {
		return textFieldEnviaMensagem;
	}

	public void setTextFieldEnviaMensagem(JTextField textFieldEnviaMensagem) {
		this.textFieldEnviaMensagem = textFieldEnviaMensagem;
	}

	public JTextField getTextFieldRecebeMensagem() {
		return textFieldRecebeMensagem;
	}

	public void setTextFieldRecebeMensagem(JTextField textFieldRecebeMensagem) {
		this.textFieldRecebeMensagem = textFieldRecebeMensagem;
	}

	public JButton getBtnEnviar() {
		return btnEnviar;
	}

	public void setBtnEnviar(JButton btnEnviar) {
		this.btnEnviar = btnEnviar;
	}

	public JButton getBtnReceber() {
		return btnReceber;
	}

	public void setBtnReceber(JButton btnReceber) {
		this.btnReceber = btnReceber;
	}

	public JButton getBtnLimparTela() {
		return btnLimparTela;
	}

	public void setBtnLimparTela(JButton btnLimparTela) {
		this.btnLimparTela = btnLimparTela;
	}

}
