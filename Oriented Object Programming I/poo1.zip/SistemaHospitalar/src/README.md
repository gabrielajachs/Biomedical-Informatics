# Sistema-Hospitalar
Implementação de um programa em Java para a simulação de um sistema hospitalar
